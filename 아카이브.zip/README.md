# IHV (인간취약성연구소 프로젝트)

- 기술 스택

  - nextjs.14
  - app router
  - server actions
  - prisma orm
  - postresql
  - vercel
  - supabase
