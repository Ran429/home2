// src/constants/institute-info.ts
export const INSTITUTE_INFO = {
  NAME: "인간취약성연구소",
  ADDRESS: "서울특별시 ○○구 ○○로 123, 인간취약성연구소",
  PHONE: "02-123-4567",
  FAX: "02-987-6543",
  EMAIL: "thevulnerables@naver.com",
};