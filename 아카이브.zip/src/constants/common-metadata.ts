import { Metadata } from "next";


 export const CommonMetadata: Metadata = {
   title: "Institute for Human Vulnerability",
   description:
     "인간취약성연구소는 현대 사회에서 발생하는 다양한 인간 취약성을 탐구하고 극복 방안을 연구하는 기관입니다.",
   applicationName: "Institute for Human Vulnerability",
   category: "연구, 교육, 사회공헌",
   keywords: [
     "인간취약성연구소",
     "Human Vulnerability Research Institute",
     "취약성 연구",
     "사회적 취약성",
     "교육 및 워크숍",
     "사회공헌",
   ],
  metadataBase: new URL("https://www.ihv.org"),
   openGraph: {
     type: "website",
     title: "Institute for Human Vulnerability",
     description:
       "현대 사회 속 인간 취약성을 탐구하고, 연구와 교육, 사회공헌 활동을 통해 극복 방안을 제시합니다.",
    url: "https://www.ihv.org",
     siteName: "Institute for Human Vulnerability",
     countryName: "KR",
     locale: "ko_KR",
   },
   verification: {
    ...(process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION
      ? { google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION }
      : {}),
     other: {
      ...(process.env.NEXT_PUBLIC_NAVER_SITE_VERIFICATION
        ? {
            "naver-site-verification": [
              process.env.NEXT_PUBLIC_NAVER_SITE_VERIFICATION,
            ],
          }
        : {}),
     },
   },
   publisher: "IHV",
   creator: "IHV",
 };