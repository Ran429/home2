export default function Loading() {
  return (
    <div className="w-screen h-screen flex justify-center items-center">
      <span className="daisy-loading daisy-loading-spinner daisy-loading-lg"></span>
    </div>
  );
}
