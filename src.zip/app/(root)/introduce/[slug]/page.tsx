import { prisma } from "@/server/prisma/prisma.client";
import { notFound } from "next/navigation";

// 페이지 타이틀을 동적으로 설정합니다.
export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug, category: "introduce" },
  });

  if (!post) {
    return {
      title: "페이지를 찾을 수 없음",
    };
  }

  return {
    title: `${post.title} | 인간취약성연구소`,
  };
}

export default async function IntroducePage({
  params,
}: {
  params: { slug: string };
}) {
  const post = await prisma.post.findUnique({
    where: {
      slug: params.slug, // URL의 slug를 사용
      category: "introduce", // '소개' 카테고리
    },
  });

  // 해당 slug의 게시물이 없으면 404 페이지를 보여줍니다.
  if (!post) {
    notFound();
  }

  return (
    <article>
      <header className="mb-8 pb-4 border-b">
        <h1 className="text-4xl font-extrabold text-gray-900">{post.title}</h1>
      </header>
      {/* 관리자 페이지의 텍스트 에디터로 저장된 HTML 형식의 콘텐츠를
        웹페이지에 그대로 보여주기 위해 사용하는 속성입니다.
      */}
      <div
        className="prose lg:prose-xl max-w-none"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />
    </article>
  );
}

