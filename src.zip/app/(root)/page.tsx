// This is the new main page for the Human Vulnerability Research Institute.

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
// import Link from "next/link"; // Removed to fix preview compilation error
import { Suspense } from "react";

// Mock data for recent posts - this will be replaced with data fetched from the database.
const mockRecentPosts = {
  events: [
    { id: 1, title: "제1회 인간취약성 컨퍼런스 개최", date: "2025.08.15" },
    { id: 2, title: "특별 초청 강연: 미래 사회와 인간", date: "2025.08.01" },
    { id: 3, title: "연구소 창립 기념 심포지엄 안내", date: "2025.07.20" },
  ],
  workshops: [
    { id: 1, title: "하계 청소년 워크숍 참가자 모집", date: "2025.08.10" },
    { id: 2, title: "데이터 분석 및 연구 윤리 교육", date: "2025.07.25" },
    { id: 3, title: "시니어 대상 디지털 리터러시 교육", date: "2025.07.15" },
  ],
  outcomes: [
    { id: 1, title: "연구 보고서: '도시의 고립과 연결'", date: "2025.08.18" },
    { id: 2, title: "학술지 게재: '디지털 시대의 새로운 취약성'", date: "2025.08.05" },
    { id: 3, title: "정책 제안: '취약계층 지원을 위한 AI 활용 방안'", date: "2025.07.28" },
  ],
};

// A reusable component for displaying a section of recent posts
function RecentPostSection({ title, posts, viewMoreLink }: { title: string, posts: {id: number, title: string, date: string}[], viewMoreLink: string }) {
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">{title}</h2>
        {/* Replaced Next.js Link with a standard <a> tag for compatibility */}
        <a href={viewMoreLink} className="flex items-center text-sm text-gray-500 hover:text-blue-600">
          더보기 <ArrowRight className="w-4 h-4 ml-1" />
        </a>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {posts.map((post) => (
          <Card key={post.id} className="flex flex-col justify-between hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-lg leading-snug">{post.title}</CardTitle>
            </CardHeader>
            <CardFooter>
              <p className="text-sm text-gray-400">{post.date}</p>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}


export default function Home() {
  return (
    <div className="flex flex-col items-center">
      {/* 1. Main Banner Section */}
      <section className="w-full h-[60vh] bg-gray-200 flex items-center justify-center">
        {/* Replace with a background image */}
        <div className="text-center">
          <h1 className="text-5xl font-extrabold text-gray-800">인간취약성연구소</h1>
          <p className="mt-4 text-lg text-gray-600">Human Vulnerability Research Institute</p>
        </div>
      </section>

      {/* 2. Recent Posts Section */}
      <main className="container mx-auto py-16 px-4 space-y-16">
        {/* Using Suspense for potential future data fetching */}
        <Suspense fallback={<div>Loading...</div>}>
          <RecentPostSection 
            title="연구소 행사" 
            posts={mockRecentPosts.events}
            viewMoreLink="/events/institute-events"
          />
        </Suspense>
        
        <Suspense fallback={<div>Loading...</div>}>
          <RecentPostSection 
            title="교육 및 워크숍" 
            posts={mockRecentPosts.workshops}
            viewMoreLink="/activities/education-workshops"
          />
        </Suspense>

        <Suspense fallback={<div>Loading...</div>}>
          <RecentPostSection 
            title="연구성과" 
            posts={mockRecentPosts.outcomes}
            viewMoreLink="/achievements/research-outcomes"
          />
        </Suspense>
      </main>
    </div>
  );
}

