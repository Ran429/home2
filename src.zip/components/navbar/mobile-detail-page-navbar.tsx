"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/drawer";
import { MENU_ITEMS } from "../../constants/menu";
import { Menu as MenuIcon } from "lucide-react";
import Link from "next/link";

// Renders the menu items within the mobile sheet, including accordions for sub-menus.
// This component is now part of MobileNavbar.tsx to resolve the import error.
function MobileMenu() {
  return (
    <div className="flex flex-col h-full p-4">
      <Link href="/" className="font-bold text-xl text-gray-800 mb-8">
        인간취약성연구소
      </Link>
      <nav className="flex-1">
        <Accordion type="multiple" className="w-full">
          {MENU_ITEMS.map((menuItem) =>
            menuItem.subItems ? (
              <AccordionItem key={menuItem.href} value={menuItem.href}>
                <AccordionTrigger className="text-lg font-semibold">
                  {menuItem.label}
                </AccordionTrigger>
                <AccordionContent>
                  <ul className="pl-4">
                    {menuItem.subItems.map((subItem) => (
                      <li key={subItem.href} className="py-2">
                        <Link
                          href={subItem.href}
                          className="text-gray-600 hover:text-blue-600"
                        >
                          {subItem.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            ) : (
              <Link
                key={menuItem.href}
                href={menuItem.href}
                className="block py-4 text-lg font-semibold border-b"
              >
                {menuItem.label}
              </Link>
            )
          )}
        </Accordion>
      </nav>
    </div>
  );
}

// The main container for the mobile navigation bar.
export default function MobileNavbar() {
  return (
    <header className="w-full fixed top-0 left-0 z-50 h-[60px] bg-white/80 backdrop-blur-sm shadow-md">
      <div className="container mx-auto flex justify-between items-center h-full px-4">
        <Link href="/" className="font-bold text-lg text-gray-800">
          인간취약성연구소
        </Link>
        <Sheet>
          <SheetTrigger asChild>
            <button className="p-2">
              <MenuIcon className="h-6 w-6" />
            </button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px]">
            <MobileMenu />
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

