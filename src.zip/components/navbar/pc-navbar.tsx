"use client";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MENU_ITEMS } from "@/constants/menu";
import { cn } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

// Renders the menu items for the desktop view, including dropdowns for sub-menus.
// This component is now part of PcNavbar.tsx to resolve the import error.
function PcMenu() {
  const pathname = usePathname();

  return (
    <ul className="flex items-center gap-x-10">
      {MENU_ITEMS.map((menuItem) => (
        <li key={menuItem.href}>
          {menuItem.subItems ? (
            <DropdownMenu>
              <DropdownMenuTrigger
                className={cn(
                  "text-lg font-semibold transition-colors hover:text-blue-600 focus:outline-none",
                  pathname.startsWith(menuItem.href)
                    ? "text-blue-600"
                    : "text-gray-700"
                )}
              >
                {menuItem.label}
              </DropdownMenuTrigger>
              <DropdownMenuContent className="mt-2">
                {menuItem.subItems.map((subItem) => (
                  <DropdownMenuItem key={subItem.href} asChild>
                    <Link href={subItem.href}>{subItem.label}</Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link
              href={menuItem.href}
              className={cn(
                "text-lg font-semibold transition-colors hover:text-blue-600",
                pathname.startsWith(menuItem.href)
                  ? "text-blue-600"
                  : "text-gray-700"
              )}
            >
              {menuItem.label}
            </Link>
          )}
        </li>
      ))}
    </ul>
  );
}

// The main container for the desktop navigation bar.
export default function PcNavbar() {
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "w-full fixed top-0 left-0 z-50 transition-all duration-300",
        isScrolled || !pathname.startsWith("/introduce")
          ? "bg-white/80 backdrop-blur-sm shadow-md"
          : "bg-transparent"
      )}
    >
      <div className="container mx-auto flex justify-between items-center h-[70px]">
        <Link href="/" className="font-bold text-xl text-gray-800">
          인간취약성연구소
        </Link>
        <nav>
          <PcMenu />
        </nav>
      </div>
    </header>
  );
}

