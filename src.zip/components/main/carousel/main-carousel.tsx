"use client";

import Autoplay from "embla-carousel-autoplay";
import useEmblaCarousel from "embla-carousel-react";
import Image from "next/image";

// 여기에 표시할 슬라이드 정보를 수정하세요.
const slides = [
  {
    imageSrc: "/images/background/main/bg_carousel2.png",
    title: "인간의 취약성, 새로운 가능성의 시작",
    subtitle: "우리는 인간의 취약성을 깊이 탐구하고 이해하여 더 나은 사회를 만듭니다.",
  },
  {
    imageSrc: "/images/background/main/bg_carousel2.png",
    title: "지식의 공유와 확산",
    subtitle: "다양한 연구 프로젝트와 교육 프로그램을 통해 지식을 나누고 함께 성장합니다.",
  },
  {
    imageSrc: "/images/background/main/bg_carousel2.png",
    title: "미래를 향한 파트너십",
    subtitle: "사회 각계각층과 협력하여 긍정적인 변화를 이끌어갑니다.",
  },
];

export default function MainCarousel() {
  const [emblaRef] = useEmblaCarousel({ loop: true }, [Autoplay({ delay: 5000 })]);

  return (
    <section className="overflow-hidden" ref={emblaRef}>
      <div className="flex">
        {slides.map((slide, index) => (
          <div className="relative flex-[0_0_100%] h-[600px] md:h-[800px]" key={index}>
            <Image
              src={slide.imageSrc}
              alt={slide.title}
              fill
              className="object-cover"
              priority={index === 0} // 첫 이미지만 우선 로딩
            />
            <div className="absolute inset-0 bg-black bg-opacity-40" />
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white p-4">
              <h1 className="text-4xl md:text-6xl font-extrabold mb-4 leading-tight">
                {slide.title}
              </h1>
              <p className="text-lg md:text-2xl max-w-3xl">
                {slide.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

