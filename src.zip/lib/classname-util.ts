export const HOVER_CLASSNAME =
  "transition-colors hover:text-klea_text_primary active:text-klea_text_primary hover:font-bold active:font-bold cursor-pointer";

/**
 * 호버, 액티브 시 강조 색상 표현
 */
export const HOVER_EMPHASIZE =
  "active:bg-klea_text_emphasize hover:bg-klea_text_emphasize transition-colors";
